const message = document.querySelector('.message-product')
const messageProductBtn = document.getElementById('message-button-product')
    messageProductBtn.addEventListener('click', ()=>{
        message.style.display = 'none';
});
